#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''

With some modifications introduced by Carolina Queiroz (May/2020)
Parts that were modified: # CQ

'''

from astropy import units as u
from astropy import wcs
from astropy.coordinates import SkyCoord
from astropy.convolution import convolve, Gaussian1DKernel
from astropy.io import fits,ascii
from astropy.table import Table,vstack,hstack
from astroquery.irsa_dust import IrsaDust
from scipy.interpolate import interp1d
from IGMabs import *
import matplotlib.pyplot as plt
from MW_unred_fitzpatrick99 import *
import numpy as np
import os
from os import path
import pandas
from scipy import interpolate

# Schlegel, Finkbeiner & Davis map of interstellar dust, 1998, ApJ 500, 525
# Return E(B-V) at a given RA,DEC from the SFD dust maps
def CalcEbv(ra, dec): 
	
	c = SkyCoord(ra=ra*u.degree, dec=dec*u.degree, frame='icrs')
	coord = c.to_string('hmsdms')
	table = IrsaDust.get_query_table(coord[0],section='ebv')
	ebv = table['ext SFD mean'][0]

	return (ebv)

# calculate the AB magnitudes given a spectrum and a set of filters	
def CalcMags(Wave, Spectrum, N_filters, FilterCurves, FilterLength, FilterType, l_eff, FilterEdges, FilterNames):

	# define output magnitude and flux density arrays	
	Mags = np.zeros(N_filters)
	F_nu = np.zeros(N_filters)

	# method of filter curve interpolation
	#intmode = 'filter' 	# interpolate filter curve on a regular grid of 10,000 points between minimum and max of the filter
	intmode = 'object' 	# interpolate filter curve on the wavelength axis of the object spectrum

	for filter in range(0,N_filters):
		int_upper = 0.
		int_lower = 0.
		TmpFilter = FilterCurves[filter,:,:]
		TmpFilter = TmpFilter[0:FilterLength[filter],:]
		lmin = TmpFilter[0,0]
		lmax = TmpFilter[-1,0]

		# minimum and maximum wavelength of the spectrum
		l1_sed = np.min(Wave)
		l2_sed = np.max(Wave)

		# the object spectrum needs to be defined from l1_filter_good and l2_filter_good, 
		# otherwise we will not be able to calculate the flux in this filter
		if l1_sed > FilterEdges[filter,0] or l2_sed < FilterEdges[filter,1]:
			print('WARNING filter ' + FilterNames[filter] + ': The object spectrum does not fully cover \
the wavelength range of the filter (magnitude set to -99)')	
			Mags[filter] = -99.
			F_nu[filter] = -99

		# it is safe to calculate a magnitude for this spectrum and this filter
		else:

			if intmode == 'filter':		# interpolate the SED on the same wavelength grid as the filter
				npoints = 10000
				dl = (lmax-lmin)/npoints
				TmpWave = np.arange(npoints,dtype=float) * dl + lmin
				TmpFilterInterp = np.interp(TmpWave,TmpFilter[:,0],TmpFilter[:,1])
				TmpSpectrum = np.interp(TmpWave,Wave,Spectrum)

			# interpolate the filter on the wavelength grid of the SED and only for the wavelength range of the filter
			if intmode == 'object':		
				TmpFilterInterp = np.interp(Wave,TmpFilter[:,0],TmpFilter[:,1])

			# valid for a photon counting device (ccd) and an input spectrum in erg/s/cm2/A
			if FilterType[filter] == 'ccd':
				flux_integral_nominator = np.trapz(TmpFilterInterp*Spectrum*Wave, x=Wave)
				flux_integral_denominator = cLight * np.trapz(TmpFilterInterp/Wave, x=Wave)

			if flux_integral_denominator != 0 and flux_integral_nominator > 0:
				F_nu[filter] = flux_integral_nominator / flux_integral_denominator
				Mags[filter] = -2.5 * np.log10(F_nu[filter]) - 48.6
				
			else:
				print('WARNING filter ' + FilterNames[filter] + ': flux integral contains negative or zero values \
(magnitude set to -99)')
				Mags[filter] = -99.
				F_nu[filter] = -99
	
	problems = (Mags == -99)
	if np.sum(problems) == 0:
		print("No warnings.")

	return (Mags, F_nu)

# Perform a chi-square calculation to determine the best-fit stellar template 
def ChiSq(stellarpath, stellarlist, stellarclass, lam, flam, dflam, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames, Mags, F_nu):
    StarFile = pandas.read_csv(stellarpath + stellarlist, names=['star_sed','star_type'], header=None, dtype={'star_sed': np.str, 'star_type': np.str}, sep=' ', skipinitialspace=True, comment='#', skip_blank_lines=True)
    StarSed = np.array(StarFile['star_sed'])
    StarType = np.array(StarFile['star_type'])

    find_subclass = np.where(StarType==stellarclass)[0]
    SedList = StarSed[find_subclass]
    N_star_sed = len(find_subclass)
    chi2 = np.zeros(N_star_sed)
    flx_scale = np.zeros(N_star_sed)

    aux = 0
    for sed in find_subclass:
        filename = StarSed[sed]
        wavelength,sed_flux = np.loadtxt(stellarpath+filename,unpack=True)
        
        # Scale the stellar template to match the current spectrum in the i-band
        StarMags, StarF_nu = CalcMags(wavelength, sed_flux, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames)
        sed_scaling_band = (FilterNames == 'SPLUS/i.dat')
        flx_scale[aux] = (F_nu[sed_scaling_band]/StarF_nu[sed_scaling_band]) 
        sed_flux_scaled = sed_flux*(F_nu[sed_scaling_band]/StarF_nu[sed_scaling_band])
        
        sed_interp = interpolate.InterpolatedUnivariateSpline(wavelength, sed_flux_scaled, k=3)
        chi2[aux] = np.sum( (flam-sed_interp(lam))**2/dflam**2 )
        aux += 1
    Chi2Min = np.argmin(chi2)
    SedName = SedList[Chi2Min]

    StarFile = stellarpath + SedName
    star_lam,star_flam = np.loadtxt(StarFile,unpack=True)
    star_flam = flx_scale[Chi2Min]*star_flam

    return (star_lam,star_flam,SedName)

# Apply a Gaussian kernel specified by the sigma to an input array and return the convolved spectrum
def ConvolveSpec(f, sigma):

    if sigma > 0:
        gauss_kernel = Gaussian1DKernel(stddev=sigma)
        f_smoothed = convolve(f, gauss_kernel, boundary='extend')
    else:
        f_smoothed = f

    return (f_smoothed)

# Convert AB magnitude to fluxes in units of erg/s/cm^2/angstrom
def FLambda(Nf,Fnu,wavelength):
    value = np.zeros(Nf)
    for filt in range(Nf):
        if Fnu[filt] != -99.:
            value[filt] = (cLight*Fnu[filt]/wavelength[filt]**2)
        else:
            value[filt] = -99.
    return (value)

# Extend the wavelength range of a spectrum by padding it with some flux values
def PadSpec(lam,flux):

    Nwavel = len(lam)
    lam_buffer = 60 #\AA

    # Extend the spectrum to a lower wavelength range 
    diff1 = lam[1]-lam[0]
    lam_blue = np.arange(100,lam[0]+lam_buffer,diff1)
    gaus_noise1 = np.random.normal(0, flux[0]/50., len(lam_blue))
    Fblue = flux[0]*np.ones(len(lam_blue)) + gaus_noise1

    # Extend the spectrum to a higher wavelength range
    diff2 = lam[-1]-lam[-2]
    lam_red = np.arange(lam[-1]-lam_buffer+diff2,15000,diff2)
    gaus_noise2 = np.random.normal(0, flux[-1]/100., len(lam_red))
    Fred = flux[Nwavel-lam_buffer]*np.ones(len(lam_red)) + gaus_noise2

    lam_ext = np.asarray(lam_blue.tolist()+lam[lam_buffer:Nwavel-lam_buffer].tolist()+lam_red.tolist())
    flux_ext = np.asarray(Fblue.tolist()+flux[lam_buffer:Nwavel-lam_buffer].tolist()+Fred.tolist())
    #dflux_ext = np.asarray((dflux[0]*np.ones(len(lam_blue))).tolist()+dflux[lam_buffer:Nwavel-lam_buffer].tolist()+(dflux[-1]*np.ones(len(lam_red))).tolist())

    return (lam_ext, flux_ext)

# CQ
# Plot the SDSS spectrum (before and after extending the blue/red sides) and corrected fluxes
def Plot(Nf,L,w_orig,f_orig,wspec,fspec,flux_no_corr,flux_corr):

    BB = np.array([0,5,7,9,11])
    NB = np.array([1,2,3,4,6,8,10])

    splus_colors = np.zeros((3,Nf), float)
    splus_colors[:,0] = (0.00, 0.00, 1.00)
    splus_colors[:,1] = (0.00, 0.25, 1.00)
    splus_colors[:,2] = (0.00, 0.65, 1.00)
    splus_colors[:,3] = (0.00, 0.50, 0.00)
    splus_colors[:,4] = (0.85, 0.65, 0.00)
    splus_colors[:,5] = (0.75, 0.50, 0.00)
    splus_colors[:,6] = (0.80, 0.25, 0.00)
    splus_colors[:,7] = (1.00, 0.00, 0.00)
    splus_colors[:,8] = (0.85, 0.00, 0.00)
    splus_colors[:,9] = (0.65, 0.00, 0.00)
    splus_colors[:,10] = (0.35, 0.00, 0.00)
    splus_colors[:,11] = (0.25, 0.00, 0.00)

    plt.figure()
    # Original spectrum (no extension, no scaling)
    plt.plot(w_orig,1.e17*f_orig,color='0.55')
    # Spectrum after scaling by i-band and extending blue/red sides with a template
    plt.plot(wspec,1.e17*fspec,color='r',linestyle='--')
    # Fluxes without completing the blue/red sides of the spectrum
    plt.plot(L,1.e17*flux_no_corr,color='k',marker='o',linestyle='none')
    # Fluxes after correcting the spectrum 
    for filt in BB:
        plt.plot(L[filt],1.e17*flux_corr[filt],color=splus_colors[:,filt],marker='s',markersize=7,markeredgecolor='k')
    for filt in NB:
        plt.plot(L[filt],1.e17*flux_corr[filt],color=splus_colors[:,filt],alpha=0.7,marker='o',markersize=6,markeredgecolor='k')

    plt.autoscale()
    plt.xlabel('$\lambda (\AA)$',fontsize=18)
    plt.ylabel('$f_{\lambda} \ $[$10^{-17} \ \mathsf{erg}.$$\mathsf{s}^{-1}.$$\mathsf{cm}^{-2}.$$\AA^{-1}$]', fontsize=18)
    plt.xlim(3000, 10000)
    plt.ylim(0.9*np.min(1.e17*fspec), 1.2*np.max(1.e17*fspec))
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    plt.rc('xtick', direction='in', labelsize=20)
    plt.tick_params(axis='both', length=6)

    plt.show()

# Add the filter transmission curves to an active plot
def PlotFilters(FilterNames, FilterCurves, FilterLen, Tmin, Tmax, col, zorder, linethick):

	for filter in range(0,len(FilterNames)):
		tmp_l = FilterCurves[filter,:,0]
		tmp_f = FilterCurves[filter,:,1]
		tmp_l = tmp_l[0:FilterLen[filter]]
		tmp_f = tmp_f[0:FilterLen[filter]]
		tmp_f = tmp_f / np.max(tmp_f)
		tmp_f = tmp_f * Tmax
		s = np.less(tmp_f, Tmin)
		tmp_f[s] = Tmin
		tmp_f[0] = Tmin
		tmp_f[-1] = Tmin
		plt.plot(tmp_l, tmp_f, '-', linewidth=linethick, color=col[filter], zorder=zorder)

	return 0

# Read filter transmission curves
def ReadFilters(filterpath,filterlist):

    FilterFile = pandas.read_csv(filterpath + filterlist, names=['filters','type','filtershortname'], header=None, dtype={'filters': np.str, 'type': np.str, 'filtershortname': np.str}, sep=' ', skipinitialspace=True, comment='#', skip_blank_lines=True)
    N_filters = FilterFile.shape[0]
    FilterName = np.array(FilterFile['filters'])
    FilterType = np.array(FilterFile['type'])
    FilterShortname = np.array(FilterFile['filtershortname'])   
    FilterLength = np.int_(np.zeros(N_filters))
    l_eff = np.zeros(N_filters) # effective filter wavelength using Gaussian approximation
    w_eff = np.zeros(N_filters) # effective filter width using Gaussian approximation
    FilterEdges = np.zeros((N_filters,2))

    max_FilterLength = 0
    print('Read ', N_filters,' filter names from the filter file.')

    # Find the longest filter
    # This will be used to define the 2D array that will hold all filters
    for filter in range(0,N_filters):
        filename = FilterName[filter]
        data = ascii.read(filterpath + filename,names=['wavelength','transmission'],converters={'wavelength': np.float, 'transmission': np.float},delimiter="\s")
        FilterLength[filter] = len(data) #data.shape[0]
    max_len_filters = max(FilterLength) 
    Filters = np.zeros((N_filters,max_len_filters,2)) 
    
    for filter in range(0,N_filters):
        filename = FilterName[filter]
        print('Opening filter '+filename)
        data = ascii.read(filterpath + filename,names=['wavelength','transmission'],converters={'wavelength': np.float, 'transmission': np.float},delimiter="\s")
        for i in range(0,FilterLength[filter]): 
            Filters[filter,i,0] = np.float_(data['wavelength'][i])
            Filters[filter,i,1] = np.float_(data['transmission'][i])
        lam = Filters[filter,0:FilterLength[filter],0]
        flux = Filters[filter,0:FilterLength[filter],1]

        # Calculate effective wavelength and effective width
        l_eff[filter] = np.trapz(flux*lam,x=lam) / np.trapz(flux,x=lam)
        w_eff[filter] = 2. * (np.trapz((lam-l_eff[filter])**2 * flux,x=lam) / np.trapz(flux,x=lam))**0.5

        # Interpolate the filter on a regular grid of 10,000 points between the 
        # minimum and maximum wavelength of the filter to select the range where the 
        # transmission is higher than some value (0.1%). Why? We want to make sure if the filter 
        # covers the spectrum. Suppose the filter file cuts off at some wavelength, and is filled with 
        # zeros beyond that, it would cover the object spectrum even though it is garbage...
        min_value = 0.001
        npoints = 10000
        lmin = np.min(lam)
        lmax = np.max(lam)
        dl = (lmax-lmin)/npoints
        dlam = np.arange(npoints,dtype=float) * dl + lmin
        dlam_Interp = np.interp(dlam,lam,flux)
        lam_range = np.where(np.greater(dlam_Interp,min_value))[0]
        lam_range_min = lam_range[0]
        lam_range_max = lam_range[-1]
        FilterEdges[filter,0] = dlam[lam_range_min]
        FilterEdges[filter,1] = dlam[lam_range_max]

    return (FilterName, Filters, FilterType, FilterLength, N_filters, l_eff, w_eff, FilterShortname, FilterEdges)

# Read SDSS spectrum
def ReadSpec(specpath,SpecName):

    #Be cautious about interpreting the reality of weak features close to 
    #these lines: 5577 \AA, 6300 \AA and 6363 \AA. They are night sky emission 
    #lines when there is auroral activity and might leave significant residuals. 

    aux = specpath + SpecName
    if path.exists(aux):

        df = fits.open(aux)
        spec = df[1].data
        info = df[2].data
        h1 = df[1].header
        h2 = df[2].header
        df.close()
        # fits is case-sensitive!
        if (spec.names[0] == 'flux') & (spec.names[1] == 'loglam') & (spec.names[2] == 'ivar'):
            lam = np.array(10. ** spec.loglam)      # assumed to be Angstrom
            flux = np.array(spec.flux * 1.e-17)     # assumed to be erg/s/cm2/A
            iVar = np.array(spec.ivar)              # inverse of variance
        elif (spec.names[0] == 'FLUX') & (spec.names[1] == 'LOGLAM') & (spec.names[2] == 'IVAR'):
            lam = np.array(10. ** spec.LOGLAM)      
            flux = np.array(spec.FLUX * 1.e-17)     
            iVar = np.array(spec.IVAR) 

        # saturated pixels are not flagged as such, but have iVar = 0.0
        # this deals with saturated pixels, avoiding artificial emission lines
        non_saturated_pix = np.argwhere(iVar!=0).flatten()
        flux = flux[non_saturated_pix]
        lam = lam[non_saturated_pix]
        flux_err = np.array(1.e-17/np.sqrt(iVar[non_saturated_pix]))

        # PLATEQUALITY = 'good' means a good science quality plate
        #plate_quality = np.array(str(info.PLATEQUALITY)[3])
        # SPECPRIMARY = 1 means this is the best observation of a particular position on the sky
        #spec_primary = np.array(int(info.SPECPRIMARY))
        RA = info['PLUG_RA']
        dec = info['PLUG_DEC']
        fiber = info['FIBERID']
        zspec = np.array(float(info.Z))
        zWarning = np.array(int(info.ZWARNING))
        # “median” signal-to-noise per resolution element from the four spectrographs
        snr_med = np.array(float(info.SN_MEDIAN_ALL))
        # zWarning_NOQSO != 0 means a fit with QSO templates with unphysical parameters, e.g. negative terms so that QSO emission lines "fit" galaxy absorption lines
        zWarning_noqso = np.array(int(info.ZWARNING_NOQSO))
        subclass = np.array(str(info.SUBCLASS)[3:4])

    return (lam,flux,flux_err,RA,dec,fiber,zspec,snr_med,zWarning,zWarning_noqso,subclass)

# Read the filenames and object types from a list 
def ReadSpecFilenames(filename):

    print("Reading list of input spectra ", filename)
    Specfile = ascii.read(filename,names=['SpecFile','petro_u','petro_g','petro_r','petro_i','petro_z','psf_u','psf_g','psf_r','psf_i','psf_z','SpecType'],delimiter="\s")

    return (Specfile)

# CQ
# Given a buffer for the SDSS spectrum, computes the redshift interval of the Lyman-alpha line
def ZLyman(lam_buffer,Wmin):
    lam_range = np.arange(Wmin,Wmin+lam_buffer+10.,10.)
    z_ly = (lam_range/1215.)-1.
    return (np.min(z_ly),np.max(z_ly))

def main():

	# current working directory
	path = os.getcwd() 

	# define other paths
	sed_path = path + '/templates/'
	filter_path = path + '/filters/'

	# define some constants
	global cLight
	GravCst = 4.3e-9 					# Mpc/Msun (km/s)^2		
	cLight = 2.9979e18 					# Angstrom/s
	h = 0.673							# h = H0/100
	Mpc2cm = 3.08568025 * pow(10,24) 	# cm per Mpc
	Lsol = 3.826e33 					# solar luminosity in erg/s
	omega_m = 0.315						# omega_matter
	omega_l = 1 - omega_m 				# omega_lambda in flat universe
	omega_k = 0.0						# curvature 

	# List of filters to be used and read the filter curves
	FilterList = 'S_PLUS_filterlist.csv'
	FilterNames, FilterCurves, FilterType, FilterLen, N_filters, l_eff, w_eff, FilterShortname, FilterEdges = ReadFilters(filter_path,FilterList)
	
	# list of spectra for which to compute synthetic magnitudes and read the list
	SpecList = 'SDSS_targets.csv'
	SpecData = ReadSpecFilenames(sed_path + SpecList)
	Nobj = len(SpecData)

	# Read spectra from the input list, apply quality cuts and compute synthetic magnitudes
	for s in range(Nobj):
		spec = SpecData[s]
		print("Processing spectrum {0:s} / {1:s} {2:s} {3:s}".format(str(s+1),str(len(SpecData)),sed_path+spec['SpecFile'],spec['SpecType']))
		lam,flux,flux_err,RA,dec,fiber,zspec,snr_med,zWarning,zWarning_noqso,subclass = ReadSpec(sed_path,spec['SpecFile'])
		# Define the SDSS magnitudes to scale the template and the spectrum
		# Choose the appropriate aperture
		Mags_SDSS = [spec['petro_u'],spec['petro_g'],spec['petro_r'],spec['petro_i'],spec['petro_z']]
		
		# CQ
		# Spectrum quality cuts
		if zWarning == 0 and zWarning_noqso == 0 and snr_med > 0:

			lamspec_min = np.min(lam)
			lamspec_max = np.max(lam)

			lam_orig = lam
			flux_orig = flux

			# calculate the magnitudes 
			print('Calculating object magnitudes ...')
			Mags, F_nu = CalcMags(lam, flux, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames)
			F_lam = FLambda(N_filters,F_nu,l_eff)

			# Scale the spectrum to match the photometry in the i-band:
			sel_scaling_band = (FilterNames == 'SPLUS/i.dat')
			magdif = Mags[sel_scaling_band]-Mags_SDSS[3]
			flux_scaled = flux * 10.**(0.4*magdif)
			flux = flux_scaled

            # If the template does not cover the full S-PLUS filter range, 
			# we use the vdBerk template for quasars or find the best stellar template
			# via chi-square minimization, to extend the spectrum in the following way:
			# 1) the vdBerk template is redshifted to the redshift of the QSO
			# 2) IGM absorption is applied to the vdBerk template using the Madau prescription and the redshift
			# 3) synthetic magnitudes of the (redshifted, IGM-absorbed) vdBerk/stellar template are calculated
			# 4) the template is scaled in the blue(red) side to the u(z)-band magnitude of the object
			# 5) we select the part of the scaled template that is below (and above?) the object spectral range
			# 6) we glue this part to the bottom and top ends of the SDSS spectrum

			# CQ
			if spec['SpecType'] == 'QSO':

				# Bad CCD column results in bogus high-z quasars
				if fiber == 40 or fiber == 59 or fiber == 60 or fiber == 833 or fiber == 839 or fiber == 840:
					print ('WARNING: bad CCD column. This may mean a spurious identification of the spectrum as a quasar at z>5.')

				# read the VandenBerk2001 template:
				sedFile = 'vandenberk.csv'
				vdb_template = pandas.read_csv(sed_path + sedFile, names=['lam','flam','flam_unc'],header=None,dtype={'lam': np.float, 'flam': np.float, 'flam_unc': np.float}, sep=',',skipinitialspace=True,comment='#',skip_blank_lines=True)
				sed_lam = np.array(vdb_template['lam'])
				sed_flam = np.array(vdb_template['flam'])
				# Apply padding
				sed_lam,sed_flam = PadSpec(sed_lam,sed_flam)

				# Deredden the spectrum using the Fitzpatrick et al. (1999) extinction curve
				eb_v = CalcEbv(RA, dec)
				print("QSO coordinates: ", RA, dec)
				print("Dereddening using E(B-V) of ", eb_v)
				if eb_v > 0.0:
					flux = MW_unred_fitzpatrick99(lam, flux, eb_v)

				# Redshift the quasar template
				sed_lam_redshifted = (1.+zspec) * sed_lam 
				# Apply IGM absorption
				vdb_flam_abs = IGMabs(zspec, sed_lam_redshifted, sed_flam) 
				# calculate the filter magnitudes of the vdb01 template
				vdb_Mags, vdb_F_nu = CalcMags(sed_lam_redshifted, vdb_flam_abs, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames)

				# scale the vdb01 template to match the current spectrum in the u-band:
				sed_scaling_blue = (FilterNames == 'SPLUS/u.dat')
				magdif = vdb_Mags[sed_scaling_blue]-Mags_SDSS[0]
				sed_flam_scaled_blue = vdb_flam_abs * 10.**(0.4*magdif)
				print('Recalculating Vanden Berk template magnitudes after scaling the blue part.')
				sed_Mags_blue, sed_F_nu_blue = CalcMags(sed_lam_redshifted, sed_flam_scaled_blue, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames)

				# scale the vdb01 template to match the current spectrum in the z-band:
				sed_scaling_red = (FilterNames == 'SPLUS/z.dat')
				magdif = vdb_Mags[sed_scaling_red]-Mags_SDSS[4]
				sed_flam_scaled_red = vdb_flam_abs * 10.**(0.4*magdif)
				print('Recalculating Vanden Berk template magnitudes after scaling the red part.')
				sed_Mags_red, sed_F_nu_red = CalcMags(sed_lam_redshifted, sed_flam_scaled_red, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames)

			# CQ
			elif spec['SpecType'] == 'STAR':

				# Perform a chi-square to determine the best stellar template
				stellarlist = 'STAR_templates.cat'
				star_lam,star_flam,StarSedName = ChiSq(sed_path, stellarlist, subclass, lam, flux, flux_err, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames, Mags, F_nu)
				
				# It is not necessary apply padding to stellar templates

				# It is not necessary to redshift the stellar templates
				sed_lam_redshifted = star_lam

				# It is not necessary to apply IGM absorption to stellar templates
				# Calculate the filter magnitudes of the stellar template
				star_Mags, star_F_nu = CalcMags(star_lam, star_flam, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames)

				# Scale the stellar template to match the current spectrum in the bands u and z
				sed_scaling_blue = (FilterNames == 'SPLUS/u.dat')
				magdif = star_Mags[sed_scaling_blue]-Mags_SDSS[0]
				sed_flam_scaled_blue = star_flam * 10.**(0.4*magdif)
				print('Recalculating stellar template magnitudes after scaling the blue part.')
				sed_Mags_blue, sed_F_nu_blue = CalcMags(star_lam, sed_flam_scaled_blue, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames)

				sed_scaling_red = (FilterNames == 'SPLUS/z.dat')
				magdif = star_Mags[sed_scaling_red]-Mags_SDSS[4]
				sed_flam_scaled_red = star_flam * 10.**(0.4*magdif)
				print('Recalculating stellar template magnitudes after scaling the red part.')
				sed_Mags_red, sed_F_nu_red = CalcMags(star_lam, sed_flam_scaled_red, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames)

			# check if it is necessary to extend the spectrum beyond its wavelengths
			shortest_wavelength_filters = np.min(FilterEdges[:,0])
			longest_wavelength_filters = np.max(FilterEdges[:,1])
			extend_lower = 'no'
			extend_higher = 'no'
			if lamspec_min > shortest_wavelength_filters:
				print("WARNING: The spectrum does not cover the lower end of the filters, but will be corrected...")
				extend_lower = 'yes'
			if lamspec_max < longest_wavelength_filters:
				print("WARNING: The spectrum does not cover the upper end of the filters, but will be corrected...")
				extend_higher = 'yes'

			if extend_lower == 'yes' or extend_higher == 'yes':
		
				# select the parts for gluing, with an additional buffer (to reduce the effects of bad parts of the spectrum at the extreme ends)
				lam_buffer = 300 #angstroms
				# CQ
				# Check if Lyman-alpha is within this wavelength range
				z_ly_min,z_ly_max = ZLyman(lam_buffer,np.min(lam))
				if zspec >= z_ly_min and zspec <= z_ly_max:
					lam_buffer = 0

				# CQ
				if extend_lower == 'yes':
					mask = np.where(np.greater(lam,lamspec_min+lam_buffer))
					lam = lam[mask]
					flux = flux[mask]
					lamspec_min_new = np.min(lam)
					sel = np.where(np.less(sed_lam_redshifted,lamspec_min_new))
					lam = np.concatenate((sed_lam_redshifted[sel],lam))
					flux = np.concatenate((sed_flam_scaled_blue[sel],flux))
				if extend_higher == 'yes':
					mask = np.where(np.less(lam,lamspec_max-lam_buffer))
					lam = lam[mask]
					flux = flux[mask]
					lamspec_max_new = np.max(lam)
					sel = np.where(np.greater(sed_lam_redshifted,lamspec_max_new))
					lam = np.concatenate((lam,sed_lam_redshifted[sel]))
					flux = np.concatenate((flux,sed_flam_scaled_red[sel]))

				# our object spectrum should now cover the entire S-PLUS wavelength range and we recalculate the magnitudes
				print('Recalculating object magnitudes after corrections...')
				Mags_corrected, F_nu_corrected = CalcMags(lam, flux, N_filters, FilterCurves, FilterLen, FilterType, l_eff, FilterEdges, FilterNames)
				F_lam_corrected = FLambda(N_filters,F_nu_corrected,l_eff)

				# CQ
				# Let's plot
				FSpec_smooth = ConvolveSpec(flux,5)
				Plot(N_filters,l_eff,lam_orig,flux_orig,lam,FSpec_smooth,F_lam,F_lam_corrected)

			# CQ: I did not check this plotting routine
			'''
			# define a fixed set of 12 colors
			col = ['#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#f58231', '#911eb4', '#46f0f0', '#f032e6', '#bcf60c', '#fabebe', '#008080', '#e6beff'] #more colors here: [, '#9a6324', '#fffac8', '#800000', '#aaffc3', '#808000', '#ffd8b1', '#000075', '#808080', '#ffffff', '#000000']

			# convert F_nu to F_lam for plotting purposes
			F_lam = np.zeros(len(Mags))
			for filter in range(len(Mags)):
				F_lam[filter] = cLight * F_nu[filter] / l_eff[filter]**2 
			if extend_lower == 'yes' or extend_higher == 'yes':
				F_lam_corrected = np.zeros(len(Mags_corrected))
				for filter in range(len(Mags_corrected)):
					F_lam_corrected[filter] = cLight * F_nu_corrected[filter] / l_eff[filter]**2 

			plt.figure(figsize=(12,6))
			LamMin = 2500. 
			LamMax = 11000.
			#sel = np.where(np.greater(flux,0.0))[0]
			Fmin = flux[0] # np.min(flux[sel])
			Fmax = 1.1 * np.max(flux)
			title = spec['SpecType'] + ' ' + spec['SpecFile'] + ' z = ' + str(zspec[0])
			plt.title(title)
			plt.xlim([LamMin,LamMax])	
			#plt.ylim([Fmin,Fmax])
			plt.yscale('log')	
			plt.xlabel('Wavelength ($\\mathrm{\\AA}$)',fontsize=15)
			plt.ylabel('Flux density (erg s$^{-1}$ cm$^{-2}$ $\\mathrm{\\AA}^{-1}$)',fontsize=15)

			# plot the filter curves
			PlotFilters(FilterNames, FilterCurves, FilterLen, Fmin, 0.8*Fmax, col, 1, 2)

			# plot the original object spectrum (red dotted curve)
			plt.plot(lam_before_ext,ConvolveSpectrum(flux_before_ext,5),'r:',zorder=2,linewidth=1)

			# plot the original, galactic dereddened object spectrum (red solid curve)
			plt.plot(lam_orig,ConvolveSpectrum(flux_orig,5),'r-',zorder=2,linewidth=1)

			# plot the synthetic magnitudes from the original spectrum (open circles)
			for p in range(0,len(l_eff)):
				plt.plot(l_eff[p],F_lam[p],marker='o',markerfacecolor='none',markersize=10,color=col[p], zorder=20)

			# plot the minimum and maximum wavelength of the original object spectrum (vertical dashed lines)
			plt.plot([lamspec_min,lamspec_min],[Fmin,Fmax],'r--')
			plt.plot([lamspec_max,lamspec_max],[Fmin,Fmax],'r--')

			if extend_lower == 'yes' or extend_higher == 'yes':

				# plot the minimum and maximum wavelength of the corrected spectrum (vertical dotted lines)
				plt.plot([lamspec_min+lam_buffer,lamspec_min+lam_buffer],[Fmin,Fmax],':',color='0.5')
				plt.plot([lamspec_max-lam_buffer,lamspec_max-lam_buffer],[Fmin,Fmax],':',color='0.5')

				# plot the corrected spectrum (black solid curve)
				plt.plot(lam,ConvolveSpectrum(flux,5),'k-',zorder=5)

				# plot the synthetic magnitudes from the corrected spectrum (filled circles)
				for p in range(0,len(l_eff)):
					plt.plot(l_eff[p],F_lam_corrected[p],marker='o',markersize=10, color=col[p],zorder=20)

				# plot the vdBerk template (grey dotted curve)
				#plt.plot(sed_lam_redshifted,ConvolveSpectrum(sed_flam_scaled,5),':',color='0.5',zorder=10)

			plt.show()
			'''

if __name__ == '__main__':
     main()